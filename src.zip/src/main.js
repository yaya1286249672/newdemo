//import Vue from 'vue'
//import App from './App.vue'
//import  VueRouter from 'vue-router';
//Vue.use(VueRouter);
//
//import index from './component/index.vue';
//import about from './component/about.vue';
//var router = [
//  {path:'/index',component:index},
//  {path:'/about',component:about},
//  {path:'*',component:index}
//];
//var routers = new VueRouter({
//  router:router   这个地方写错啦 笨蛋！！！
//});
//new Vue({
//el: '#app',
//  router:routers,
//render: h => h(App)
//})

import Vue from 'vue'
import App from './App.vue'
import  VueRouter from 'vue-router';
Vue.use(VueRouter);

import index from './component/index.vue';
import about from './component/about.vue';
import find from './component/find.vue';
import in1 from './component/in1.vue';
import in2 from './component/in2.vue';
var router = [
    {
        path:'/index',
        component:index,
        children:[
            {
            path:'/in1',
            componemt:in1
        }, {
                path:'/in2',
                componemt:in2
            }
        ]
    },
    {path:'/about',component:about},
    {path:'/find',component:find},
    {path:'*',component:index}
];
var routers = new VueRouter({
    routes: router   
});
new Vue({
  el: '#app',
    router:routers,
  render: h => h(App)
});
