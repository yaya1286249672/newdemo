<template id = "in2">
    <div>
        <h2>
            页面2
        </h2>
    </div>
</template>
<script type = "text/javascript">
    var in2 = {
        template:"#in2",
        data:function(){
            return{

            }
        }
    };
    module.exports = in2;
</script>