<template id = "in1">
    <div>
        <h2>
            页面1
        </h2>
    </div>
</template>
<script type = "text/javascript">
    var in1 = {
        template:"#in1",
        data:function(){
            return{

            }
        }
    };
    module.exports = in1;
</script>