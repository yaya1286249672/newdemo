<template id = "find">
    <div>
        <h2>
            发现页面
        </h2>
    </div>
</template>
<script type = "text/javascript">
    var find = {
        template:"#find",
        data:function(){
            return{

            }
        }
    };
    module.exports = find;
</script>