<template id = "about">
    <div>
        <h2>
            about页面
        </h2>
    </div>
</template>
<script type="text/javascript">
    var about = {
        template:"#about"
    };
    module.exports = about;
</script>